# PDF Build Verification — final local preflight

{
  "schema": "brphm-pdf-build-verification-v2",
  "created_utc": "2026-10-02T18:52:34Z",
  "scope": "Local source/PDF reproducibility and production preflight. This record is not a venue PDF eXpress or accessibility certification.",
  "source": {
    "path": "work/paper/en/main.tex",
    "sha256": "a6fa47353027862afeec3fe9b37c43984887e4738b4f528a854a71fb5587d783",
    "bytes": 35188
  },
  "pdf": {
    "path": "work/paper/en/main.pdf",
    "sha256": "cb49907939e88aa0404368a5041ca12c1e626c82d672f6d5e7d0eabb118b1c83",
    "bytes": 323253,
    "pages": 6,
    "page_size_points": [
      612,
      792
    ],
    "paper_size": "letter",
    "pdf_version": "1.5",
    "tagged": false
  },
  "build": {
    "commands": [
      "pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex (pass 1)",
      "pdflatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex (pass 2)"
    ],
    "engine": "MiKTeX-pdfTeX (see pdfinfo/latex log)",
    "note": "This record audits the final two-pass build; it does not invoke pdflatex."
  },
  "pdfinfo": {
    "exit_code": 0,
    "Title": "Auditing Source-Label-Only Route Selection for Cross-Orbit Remaining-Useful-Life Prediction",
    "Subject": "",
    "Keywords": "",
    "Author": "Author metadata pending confirmation",
    "Creator": "LaTeX with hyperref",
    "Producer": "MiKTeX pdfTeX-1.40.28",
    "CreationDate": "Sat Oct  3 02:51:58 2026 �й���׼ʱ��",
    "ModDate": "Sat Oct  3 02:51:58 2026 �й���׼ʱ��",
    "Custom Metadata": "yes",
    "Metadata Stream": "no",
    "Tagged": "no",
    "UserProperties": "no",
    "Suspects": "no",
    "Form": "none",
    "JavaScript": "no",
    "Pages": "6",
    "Encrypted": "no",
    "Page size": "612 x 792 pts (letter)",
    "Page rot": "0",
    "File size": "323253 bytes",
    "Optimized": "no",
    "PDF version": "1.5"
  },
  "font_check": {
    "command": "pdffonts en/main.pdf",
    "exit_code": 0,
    "fonts": [
      {
        "name": "QOKJQO+NimbusRomNo9L-Regu",
        "type": "Type",
        "encoding": "1",
        "emb": "Custom",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 108 0"
      },
      {
        "name": "LREKMX+NimbusRomNo9L-MediItal",
        "type": "Type",
        "encoding": "1",
        "emb": "Custom",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 110 0"
      },
      {
        "name": "IQBQDU+NimbusRomNo9L-Medi",
        "type": "Type",
        "encoding": "1",
        "emb": "Custom",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 111 0"
      },
      {
        "name": "CZVSSV+CMR9",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 112 0"
      },
      {
        "name": "PQILTH+CMMI9",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 113 0"
      },
      {
        "name": "OPEKTB+CMSY9",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 114 0"
      },
      {
        "name": "HBIEHQ+CMSY6",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 115 0"
      },
      {
        "name": "SJQNVY+CMR6",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 116 0"
      },
      {
        "name": "YSAXAY+CMSY7",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 117 0"
      },
      {
        "name": "UGRNYW+NimbusRomNo9L-ReguItal",
        "type": "Type",
        "encoding": "1",
        "emb": "Custom",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 130 0"
      },
      {
        "name": "XZOKWA+NimbusMonL-Regu",
        "type": "Type",
        "encoding": "1",
        "emb": "Custom",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 131 0"
      },
      {
        "name": "PSQRFP+CMR10",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 133 0"
      },
      {
        "name": "TGBNJD+CMSY10",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 134 0"
      },
      {
        "name": "HSMEMO+CMMI10",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 135 0"
      },
      {
        "name": "FADMTX+CMMI7",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 136 0"
      },
      {
        "name": "GJAANQ+CMEX10",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 138 0"
      },
      {
        "name": "ZXOPOM+CMR7",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 139 0"
      },
      {
        "name": "QDTWCG+MSBM10",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 140 0"
      },
      {
        "name": "CUUNJW+CMMI5",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 141 0"
      },
      {
        "name": "EYETKE+DejaVuSans",
        "type": "CID",
        "encoding": "TrueType",
        "emb": "Identity-H",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 161 0"
      },
      {
        "name": "DEOWHK+DejaVuSans",
        "type": "CID",
        "encoding": "TrueType",
        "emb": "Identity-H",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 162 0"
      },
      {
        "name": "BAEDIA+DejaVuSans",
        "type": "CID",
        "encoding": "TrueType",
        "emb": "Identity-H",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 176 0"
      },
      {
        "name": "HMPEFZ+CMSY5",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 190 0"
      },
      {
        "name": "NXBXRT+CMR5",
        "type": "Type",
        "encoding": "1",
        "emb": "Builtin",
        "sub": "yes",
        "uni": "yes",
        "object_id": "yes 191 0"
      }
    ],
    "all_embedded": false,
    "type3_count": 0,
    "result": "FAIL"
  },
  "text_extraction": {
    "command": "pdftotext main.pdf main_extracted.txt",
    "exit_code": 0,
    "bytes": 32020,
    "sha256": "77928910208f1efe8305855df1d504c727c3fee02dea85650377da033d6a71cb"
  },
  "log_scan": {
    "warning_line_count": 28,
    "underfull_hbox_count": 28,
    "overfull_hbox_count": 0,
    "fatal_or_error_count": 0,
    "sample": [
      "Underfull \\hbox (badness 10000) in paragraph at lines 45--46",
      "Underfull \\hbox (badness 3333) in paragraph at lines 45--46",
      "Underfull \\hbox (badness 5288) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 10000) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 8113) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 10000) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 10000) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 10000) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 10000) in paragraph at lines 75--76",
      "Underfull \\hbox (badness 10000) in paragraph at lines 89--90",
      "Underfull \\hbox (badness 2495) in paragraph at lines 89--90",
      "Underfull \\hbox (badness 1796) in paragraph at lines 89--90"
    ]
  },
  "hashes": {
    "work/paper/en/main.tex": "a6fa47353027862afeec3fe9b37c43984887e4738b4f528a854a71fb5587d783",
    "work/paper/en/main.pdf": "cb49907939e88aa0404368a5041ca12c1e626c82d672f6d5e7d0eabb118b1c83",
    "work/paper/en/main.log": "231e46b0b8c1998ab2757325764dcf0b5db4973469782c65c8a3879e7faaa622",
    "work/paper/en/main_extracted.txt": "77928910208f1efe8305855df1d504c727c3fee02dea85650377da033d6a71cb"
  },
  "local_checks": {
    "double_compile_recorded": true,
    "letter_page_size": true,
    "type3_absent": true,
    "fonts_embedded": false,
    "text_extraction": true,
    "fatal_errors_absent": true,
    "overfull_absent": true,
    "underfull_absent": false,
    "tagged_pdf": false
  },
  "venue_checks": {
    "target_venue": "PENDING exact venue, track, article type, and review mode",
    "pdf_express": "PENDING exact venue/article type",
    "accessibility": "PENDING exact venue policy/checker",
    "blind_review_metadata": "PENDING exact venue policy"
  },
  "result": "Local PDF facts are hash-linked; venue-specific PDF eXpress and accessibility checks remain pending.",
  "residual_risk": "Underfull boxes and an untagged PDF remain; the exact venue and checker are not selected."
}
